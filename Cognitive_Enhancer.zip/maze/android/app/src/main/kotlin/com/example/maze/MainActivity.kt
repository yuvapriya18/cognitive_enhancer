package com.example.maze

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
