import 'package:flutter/material.dart';
import 'math_quiz.dart';
import 'maze.dart';
import 'memory.dart';
import 'analysis.dart';
import 'order_game.dart';
import 'api.dart';
import 'info.dart';

void main() {
  runApp(MyApp1());
}

class MyApp1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Home Page',

        home: Scaffold(
        appBar: AppBar(
        title: Text('Cognitive Enhancer'),
    centerTitle: true,

    leading: IconButton(
    icon: Icon(Icons.arrow_back),
    onPressed: () {
    Navigator.of(context).pop(); // Navigate back to the previous screen
    },
    ),
    ),
    body: Center(
    child: HomePage(),
    ),
    ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return
         Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              child: Image.asset(
                'assets/img.png', // Replace 'your_image.png' with the path to your image asset
                width: 200, // Adjust width as needed
                height: 200, // Adjust height as needed
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MathQuizScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: Text('Math Quiz'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MazeScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: Text('Maze Game'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MemoryGameScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: Text('Memory Game'),
            ),
            SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OrderingGame()),
                );
              },
              style: ElevatedButton.styleFrom(
                shape: const StadiumBorder(),
                padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              ),
              child: Text('Order Game'),
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyAnalysis()),
                );
              },
              child: Container(
                width: 200,
                height: 50,
                color: Colors.deepOrangeAccent[100],
                child: Center(child: Text('Analysis')),
              ),
            ),
            SizedBox(height: 20),

            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Api()),
                );
              },
              child: Container(
                width: 200,
                height: 50,
                color: Colors.deepOrangeAccent[100],
                child: Center(child: Text('Aids available')),
              ),
            ),
          ],



    );
  }
}
