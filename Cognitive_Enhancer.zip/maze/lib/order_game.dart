import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(OrderingGame());
}

class OrderingGame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      //home: OrderingScreen(),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Analysis'),
          centerTitle: true,

          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context).pop(); // Navigate back to the previous screen
            },
          ),
        ),
        body: Center(
          child: OrderingScreen(),
        ),
      ),
    );
  }
}

class OrderingScreen extends StatefulWidget {
  @override
  _OrderingScreenState createState() => _OrderingScreenState();
}

class _OrderingScreenState extends State<OrderingScreen> {
  List<String> objects = ["Hello", "Joy", "Glass", "Bicycle", "Bottle"];
  List<String> orderedObjects = [];
  bool gameOver = false;
  String feedback = '';

  @override
  Widget build(BuildContext context) {
    return
       Column(
        children: <Widget>[
          SizedBox(height: 20),
          Text(
            'Order the Words lexicographicaly:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Container(
            height: 200,
            child: ListView.builder(
              itemCount: orderedObjects.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(orderedObjects[index]),
                );
              },
            ),
          ),
          SizedBox(height: 20),
          Container(
            height: 200,
            child: ListView.builder(
              itemCount: objects.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(objects[index]),
                  onTap: () {
                    if (!gameOver) {
                      setState(() {
                        orderedObjects.add(objects[index]);
                        objects.removeAt(index);
                      });
                      if (objects.isEmpty) {
                        setState(() {
                          gameOver = true;
                          checkOrder();
                        });
                      }
                    }
                  },
                );
              },
            ),
          ),
          SizedBox(height: 20),
          Text(
            feedback,
            style: TextStyle(
              color: feedback == 'Congratulations!' ? Colors.green : Colors.red,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20),
          if (gameOver)
            ElevatedButton(
              onPressed: () {
                setState(() {
                  restartGame();
                });
              },
              child: Text('Play Again'),
            ),
        ],
      );

  }

  void restartGame() {
    // Resetting the game
    objects = generateRandomWords();
    orderedObjects.clear();
    gameOver = false;
    feedback = '';
  }

  void checkOrder() {
    bool correctOrder = true;
    for (int i = 0; i < orderedObjects.length - 1; i++) {
      if (orderedObjects[i].compareTo(orderedObjects[i + 1]) > 0) {
        correctOrder = false;
        break;
      }
    }

    if (correctOrder) {
      feedback = 'Congratulations!';
    } else {
      feedback = 'Oops, try again';
    }
  }

  List<String> generateRandomWords() {
    List<String> words = ["Hello", "Joy", "Glass", "Bicycle", "Bottle"];
    words.shuffle();
    return words;
  }
}