import 'package:flutter/material.dart';
import 'main1.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'User Type Selection',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: UserTypeSelectionPage(),
    );
  }
}

class UserTypeSelectionPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cognitive Enhancer'),
        backgroundColor: Colors.teal,
        centerTitle: true,

      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                'assets/img.png', // Replace this with your image path
                height: 150, // Adjust the height of the image as needed
              ),
              SizedBox(height: 20),
              Text(
                'Select your user type:',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Navigate to Login/Signup page for doctors
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => DoctorLoginSignupPage()),
                  );
                },
                child: Text('Doctor'),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  // Navigate to Login/Signup page for parents
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ParentLoginSignupPage()),
                  );
                },
                child: Text('Parent'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class DoctorLoginSignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Login/Signup'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Select an option:',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to Doctor Login page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorLoginPage()),
                );
              },
              child: Text('Login'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Navigate to Doctor Signup page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorSignupPage()),
                );
              },
              child: Text('Signup'),
            ),
          ],
        ),
      ),
    );
  }
}

class ParentLoginSignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Parent Login/Signup'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Select an option:',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Navigate to Parent Login page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyApp1()),
                );
              },
              child: Text('Login'),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () {
                // Navigate to Parent Signup page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ParentSignupPage()),
                );
              },
              child: Text('Signup'),
            ),
          ],
        ),
      ),
    );
  }
}

class DoctorLoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Login'),
      ),
      body: Center(
        child: Text('Doctor Login Page'),
      ),
    );
  }
}

class DoctorSignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Signup'),
      ),
      body: Center(
        child: Text('Doctor Signup Page'),
      ),
    );
  }
}

class ParentLoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Parent Login'),
      ),
      body: Center(
        child: Text('Parent Login Page'),
      ),
    );
  }
}

class ParentSignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Parent Signup'),
      ),
      body: Center(
        child: Text('Parent Signup Page'),
      ),
    );
  }
}
