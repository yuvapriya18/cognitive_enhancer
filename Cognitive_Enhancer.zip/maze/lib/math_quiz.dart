import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(MathQuizApp());
}

class MathQuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Math Quiz',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MathQuizScreen(),
    );
  }
}

class MathQuizScreen extends StatefulWidget {
  @override
  _MathQuizScreenState createState() => _MathQuizScreenState();
}

class _MathQuizScreenState extends State<MathQuizScreen> {
  int num1 = 0;
  int num2 = 0;
  int answer = 0;
  List<String> options = [];
  Color optionColor = Colors.transparent; // Initialized optionColor

  @override
  void initState() {
    super.initState();
    generateQuestion();
  }

  void generateQuestion() {
    setState(() {
      Random random = Random();
      num1 = random.nextInt(10); // Random number between 0 and 9
      num2 = random.nextInt(10);
      answer = num1 + num2;

      options.clear();
      options.add(answer.toString());
      while (options.length < 4) {
        int option = random.nextInt(19); // Random number between 0 and 18
        if (!options.contains(option.toString()) && option != answer) {
          options.add(option.toString());
        }
      }
      options.shuffle();
      optionColor = Colors.transparent;
    });
  }

  void checkAnswer(String selectedAnswer) {
    setState(() {
      final bool isCorrect = int.parse(selectedAnswer) == answer;
      optionColor = isCorrect ? Colors.green : Colors.red;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Math Quiz'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              '$num1 + $num2 = ?',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Wrap(
              spacing: 10,
              children: options.map((option) {
                return ElevatedButton(
                  onPressed: () {
                    checkAnswer(option);
                  },
                  child: Text(
                    option,
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                      optionColor,
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                generateQuestion();
              },
              child: Text('Next'),
            ),
          ],
        ),
      ),
    );
  }
}